from transports import *

ritenis = TransportLidzeklis("Ērempreiss", 1979, "zilā", "aizmugures")
#Izmantojam metodi pārkrāsot
ritenis.parkrasot("zaļā")
#Nomainam piedziņu ar metodi mainit_piedzinu
ritenis.mainit_piedzinu("priekšas")
#Izdrukājam informāciju par transportlīdzekli
ritenis.info()
#Mēģinam vēlreiz nomainīt piedziņu uz jau esošu
ritenis.mainit_piedzinu("priekšas")

auto = Masina("Audi", 1999, "pelēkā", "priekšas", 4)
#Izdrukājam informāciju par auto
auto.info()
#Norakstam auto ar metodi norakstit
auto.norakstit()
#Izdrukājam informāciju par auto
auto.info()
#Mēģinam vēlreiz norakstīt
auto.norakstit()
#Nomainam piedziņu ar vecāka klases metodi mainit_piedzinu
auto.mainit_piedzinu("pilnpiedziņas")
#Izdrukājam informāciju par auto
auto.info()
#Nomainam krāsu ar vecāka klases metodi parkrasot
auto.parkrasot("melna")
#Izdrukājam informāciju par auto
auto.info()