from .transportlidzeklis import TransportLidzeklis

#Bērna klase TransportLidzeklis klasei un tās metodes         
class Masina(TransportLidzeklis):
    def __init__(self, razotajs, izlaiduma_gads, krasa, piedzina, durvju_skaits):
        super().__init__(razotajs, izlaiduma_gads, krasa, piedzina)
        self.durvju_skaits = durvju_skaits
        self.uzskaite = True
    def norakstit(self):
        if self.uzskaite == True:
            print(f"Automašīna {self.razotajs} norakstīta!")
            self.uzskaite = False
        else:
            print(f"Automašīna {self.razotajs} nav uzskaitē!")
    def info(self):
        if self.uzskaite:
            uzskaites_status = "uzskaitē"
        else:
            uzskaites_status = "norakstīta"
        print(f"Auto ražotājs ir {self.razotajs}, tā izlaiduma gads ir {self.gads}, tas ir {self.krasa} krāsā un tam ir {self.piedzina} piedziņa! Auto ir {self.durvju_skaits} durvis! Un tā ir {uzskaites_status}!")